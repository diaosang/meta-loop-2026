"""V14 user canon. Apply fixed biographies across the active data, not historical playables."""
from pathlib import Path
import json, re
P=Path(__file__).resolve().parent
def read(n): return json.loads((P/(n+'.json')).read_text(encoding='utf-8'))
def write(n,d): (P/(n+'.json')).write_text(json.dumps(d,ensure_ascii=False,separators=(',',':')) if n in ('world-data','cast-data') else json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')

intro=[
'大梁立国百余年。先帝晚年，皇权式微，边关连年用兵，世家盘踞六部，诸侯拥兵自重。储位之争里，几位成年皇子或暴毙宫闱，或死于途中，或以谋逆之名连累母族。东宫的灯，每亮一盏，便要熄一盏。',
'先帝崩殂时，皇室竟只余十九岁的九公主。她无意争位，也未受过完整的储君教养，甚至来不及哀恸，便被姜、叶两族以延续国祚之名拥上龙椅，改元景和。朝廷仍称大梁，改元并不另立一个王朝。',
'群臣山呼万岁，殿中却没有几个人真正等她裁决。姜氏要握住诏令，叶氏不肯让姜氏独揽，边镇只等钱粮。首辅许知衡立在阶下，曾经的婚约早已解除；谢无咎守在帘外，递来的每页消息都有未写尽之处。她今日能拨的国库银粮，仍是零。']
core={
'xu':dict(name='许知衡',age=24,role='内阁首辅 · 帝师遗孤',type='清冷克制',romance=True,loyalty=94,ambition=42,influence=64,
 desc='许阁老遗孙，旧案失势后重返朝堂。与你曾有婚约，忠于君上，却不肯以首辅印换后宫名位。',
 public='许家曾领清流。祖父许阁老三朝为官，亦是九公主年少的授业恩师，因弹劾世家与追问夺嫡阴私，被构陷死于旧案。许知衡与九公主的婚约也随家族失势而解除，后来才重返内阁。',
 originReply='祖父从前教过陛下。许家出事后，婚约随之解除；臣今日站在这里，凭的是朝廷授下的职责，不敢以旧约相挟。',
 scar='旧卷封着，证人散着。臣不能因为死的是自己的祖父，便将猜测写成证据；可也不能因为难查，就当那场事从未发生。',
 truth='臣想站在陛下身边。首辅的职责会尽，许家的旧案会查，至于这点私心……臣不愿拿它换一纸册封。',
 want='查清祖父冤案，扶持女帝亲政；在相互选择中并肩，而非入宫承宠',daily='将祖父旧案线索与当日阁务分开存放，先呈该办的公文。',item='许阁老旧案封签与原疏副本',evidence='副本可与宫门收文日期互校，足以重核结状时序；不能据此直接指认为哪一家主使。'),
'jiang':dict(name='姜禹瀛',age=32,role='世家太傅 · 姜氏执棋者',type='戒备善谋',romance=True,loyalty=38,ambition=84,influence=86,
 desc='拥立你的姜氏嫡系。解围时温雅周全，谈到荐举、签押与兵权，却从不轻易退让。',
 public='姜氏百年仕宦，与叶氏有数代姻亲。姜禹瀛出自嫡系，以太傅之职辅政，也肩负家族掌握朝局的重任。姜叶联合拥立九公主，联姻同盟却并不等于利益一致。',
 originReply='姜氏与叶氏共奉遗制，迎陛下即位。臣如今奉太傅之职，讲授治国，也替姜氏担着该担的分量。这一点，不必说成全无私心。',
 scar='叶氏要钱粮，姜氏要荐举，到了兵权，两边便都不肯退。臣若只教陛下几句圣贤书，倒是将真正要紧的事藏起来了。',
 truth='臣原以为，只须替陛下安排妥当。如今您能看出臣留了什么，臣竟既不悦，又有些……不愿您看不出来。',
 want='维持姜氏掌权、制衡叶氏与许知衡；女帝的独断与私人感情均可能打乱其计划',daily='分别核阅姜氏荐单与叶氏来函，只将有据的部分带入廷议。',item='姜叶两份人事荐单',evidence='两份荐单在刑部主事人选上相争，证实人事利益并不一致；姻亲与荐举往来本身不是谋逆实据。'),
'xie':dict(name='谢无咎',age=25,role='内廷掌事 · 御前旧人',type='圆融世故',romance=True,loyalty=92,ambition=46,influence=58,
 desc='公主时便伴你左右的掌事。宫中耳目、京城暗线与商贾人脉，都可到他手里；他递来的话，仍须分清亲见、转述和未核。',
 public='谢无咎无显赫家门，自九公主未登基时便在内廷服侍。如今掌理宫中消息，与京中商贾、江湖人脉都有往来；他的忠诚有旧事作根，旧事本身却尚未说清。',
 originReply='奴才在陛下还是公主时便跟着了。宫里认得的是这份当值身份，至于从前的来处，奴才还没全说。',
 scar='有些信源只能见奴才，不能见官。奴才交得出线索，不等于交得出每一个人；陛下若另派人核，奴才也知道这是该有的防备。',
 truth='奴才不是净过身的内侍。这层身份藏了多年，今日是自己说给陛下听。至于为何把命押在您这里，奴才还欠您一段旧事，不敢拿一句救命之恩敷衍过去。',
 want='维系女帝与自己的生路，掌握情报主动权；既能奉上真相，也会保留底牌',daily='将内廷亲见、京中转述和商路来信分列，封存尚不能互证的那一页。',item='分列信源的消息册',evidence='两条不同来路可互证旧卷移交时间；交叉核验前，谢无咎的判断不作为定罪凭据。')}

dialogue=[]
def lines(npc,topic,tier,texts):
 for i,text in enumerate(texts):dialogue.append(dict(id=f'daliang:{npc}:{topic}:{tier}:{i}',semantic=f'daliang:{npc}:{topic}:{tier}:{i}',npc=npc,category='care' if topic in ('listen','comfort') else 'chat',topic=topic,minTier=tier,reply=text))
for npc,topics in {
'xu':{
'listen':[['臣近来无恙。阁务按轻重理着，尚不至于误事。','一切如常。只是旧卷看得久，起身时肩背有些僵，走几步便好。','还算顺遂。今日该办的都列清了，没有将家中的事混在里面。'],['近来忙些，不过不是回回都为了旧案。臣也会看闲书，只是总有人以为又在查什么。','想将夜里看卷的时辰缩短些。白日辨不清的，熬到夜里也未必能辨清。'],['是有些累。您既问的是臣，今日便不拿一摞办好的折子来答了。','公事尚能料理。倒是有时想来见您，找了半日由头，才想起不该句句都是公事。']],
'comfort':[['吃睡都还好，没受寒。臣会顾着，不劳陛下忧心。','近来没有病痛。读卷时会停一停，不必将一夜都耗进去。','用饭如常。案卷收好后再吃，免得一心两用。'],['这几日没熬到更深。旧案不是少睡一夜便能查清的，臣知道。','茶倒喝得有些多，正想减一盏。总不能白日提神，夜里又怪自己睡不着。'],['偶有醒来便惦着卷宗的时候。不是不能睡，是一时不肯将它放下。','您来时，方才还想把那页看完。如今先搁着，也并非就会误了什么。']],
'recent':[['在核今日的阁务。该另议的分开，不挤在一页上。','翻到祖父从前的一处批注，先记下出处，未急着作解。','在理旧书。常用的放在手边，免得临时又找。'],['在看一处旧案的收文日期。只差一日，所指的先后便不同，不能凭记性。','今日先收了卷。越是想一口气看明白，越容易将猜测看成事实。'],['原想着将案上理妥再请您坐。看来若真等全理妥，今日又只能在殿上见了。','书看得慢，倒不是不专心。是读到一处，总想问您会怎样看。']],
'home':[['祖父是陛下年少的老师。许家旧事，臣记得，案卷上却还有许多未核清。','婚约解除已有数年。臣不会拿旧日约定，来索今日的回答。','从前祖父教人，先问所据何在。如今查他的案，更不能违这句话。'],['当年许家出事，许多熟人连信也不敢回。也不能因此便认定每个沉默的人都有罪。','祖父的书还留着。有些夹签已脆，翻时不敢太急。'],['旧约不在了，臣知道。若还有后来，也只能是您与臣今日重新选的。','从前我也以为，读懂了书，便能护住家里的人。后来才知，要学的远不止书上那些。']],
'interest':[['闲时读些杂记，不独看经史。人情世故，也并非都写在奏章上。','喜欢习字。写得不妥便留着重练，不是每一页都须拿给人看。','偶尔看棋谱。纸上想得再周全，执子时仍要自己取舍。'],['喜欢看书边的批注。有人只写两字，倒比长篇议论更叫人想知道缘由。','偶尔也想只喝一盏茶，不问接下来该做什么。'],['您若来，书留一半也无妨。臣并非次次都须当那个讲书的人。','有意思的几页还未看完。今日若得空，想听听您与臣不同的那一处。']]},
'jiang':{
'listen':[['臣近来都好。太傅的课与族中来函分开理着，不至于相混。','近日事务略多，尚应付得来。姜氏的荐单，臣会另列出处。','没有不适。只是回函要斟酌，笔停得久，并非身子不济。'],['近来想少带几份荐书到御前。不是不想替人说话，是有些话说得越满，越难收回。','叶家来信仍客气。越客气的时候，往往越要看清末尾那一句。'],['您问近况，我却先想该回哪一份公事。这习惯，看来还没那么容易改。','有时也想把族里的事放一放。只是臣说了这句，明日仍会去看荐单，陛下可别误以为臣已全放下。']],
'comfort':[['起居如常，陛下不必忧心。臣没有拿熬夜当勤勉的习惯。','吃睡都好。用饭时先将来函收起，倒比看着它们更有胃口。','未曾受寒。课后会走几步，不在案边一坐就是半日。'],['近日茶喝得淡些。家书看得再晚，也不好再添一盏浓的。','夜里能歇。真要紧的事先记着，不必时时摆出不肯休息的样子。'],['是有过辗转的时候。未必全为政事，只是有些事，臣还不愿说得太明。','您既认真问，臣也认真答：最近确实歇得少，今日便不再替自己找漂亮说辞了。']],
'recent':[['在重排下一回的讲题。先讲如何辨荐书，不急着讲一句空泛的君道。','核了两份荐单，人选不同，所据也不同。臣正将差别列出来。','方才读叶氏来函。礼数周全，所求却不能只看字面。'],['在想一道题，若没有姜氏替它兜底，臣还会不会照原先的办法答。','今日的课想留一个反例。若事事都按臣说的便对，倒不像教陛下治国了。'],['想好的一番话，见着您又须重想。陛下如今越来越会挑出臣没说的那半句。','荐单放下了。您若只来坐坐，臣今日也试试不将每句话都引回课上。']],
'home':[['姜氏与叶氏有姻亲，也有各自要守的东西。同席用茶，不等于事事同心。','臣出自姜氏嫡系。从小听的许多话，都先问对家门有什么用。','两家共迎陛下登基，功劳可以记，往后的官职却仍须一件件议。'],['家里最爱说成例。可若每一桩旧例都正好利于姜氏，陛下便该多问一句。','叶氏不会愿意让姜氏独掌。臣同样如此，未必因为笑着说话，便没有这点心思。'],['有些话，臣既替姜氏说过，便不能如今装作全无此事。只是您若要听臣自己的意思，臣会另说。','从前觉得家门与自己本是一回事。如今偶有分不清的时候，倒不知该怪谁。']],
'interest':[['闲时读史。尤其看一项旧制，是怎样在不知不觉间变成了另一回事。','也喜欢对弈。输赢有趣，知道自己在哪一步看轻了对手，更有趣。','偶尔习字。字要收得住，人未必能，因而更须练。'],['看棋时喜欢留一处未定。都算尽了，旁人的下一手便没什么意思。','有时读完旧事，想的不是谁对谁错，而是当时还有没有别的路。'],['您如今落子，已不像在答臣出的题了。臣不敢说全无失落，倒也舍不得不看。','得闲时，也会想听一句不问利害的话。只是先说好，臣未必就答得好。']]},
'xie':{
'listen':[['奴才近来都好。内廷当值照旧，京中的来话已另交人分轻重。','没什么不适。今日走得多些，坐一刻便缓过来了。','近来没有为难的私事。要紧消息会另报，不拿来占这句问候。'],['闲下来也总留意门外，一时改不过来。倒不是处处有事，只是听惯了。','最近想少带些东西在袖中。带得齐全，临取时反而要多摸一回。'],['是有些乏。平日回“都好”顺口，您这么认真看着，奴才倒说不出口了。','近来总在想，空着手进来一回，会不会显得贪闲。如今看来，先问的倒是陛下。']],
'comfort':[['饭吃过了，夜里也能歇。奴才没有不适。','嗓子还好，回话多时便先喝些水。谢陛下惦念。','没有受凉。出入宫门，衣裳总会先添一件。'],['这几日试着把饭用慢些。若没人催，原也不必总急着放箸。','水记得趁温喝了，没回回都等它凉透。'],['睡着不难，只是醒来总要先看时辰。您若准奴才闲坐一会儿，这一会儿便先不看。','有时确实忘了饭点。不是没人管，是自己总想先将人送走、将话核完。']],
'recent':[['在核几条京中来话。亲见与转述分开，未核的暂不作实报。','将商路来的信另放了一层，免得与宫中亲见的事混在一处。','看了几页闲书。不是每回翻纸，都是在找谁的把柄。'],['正想找个不用递话的地方坐坐，回头又先留了个能看见门的座。','京中话传得快，原来三个字，过几道手便能变成一段。倒比话本还会添。'],['今日没有要紧事须报。陛下若是来看人的，奴才便不再从袖里找一页纸出来。','想着给您递茶。许首辅与姜大人都各有一番道理，奴才今日先不替谁添这把火。']],
'home':[['奴才在陛下还是九公主时便伴着了。再早的事，宫里知道的人并不多。','没什么显赫家门可说。如今认得的人多些，也不是一日便织出来的。','内廷之外也须有人。商贾、行客各有见闻，听过还要分得清。'],['从前替陛下传话，最怕的不是路远，是一句话到了人前，已不再是原来那句。','那时宫里人人怕说错话。奴才学的第一件事，是先听清谁真正有能力做些什么。'],['奴才为何留在陛下身边，确有一段旧事。只是如今不想随便拣个救命之恩，就哄您相信全懂了。','有些底牌藏得太久，拿出来倒比藏着更难。陛下若真问，奴才会先分清，哪些今日能说。']],
'interest':[['闲时看话本。看得慢，不必一夜便知道结尾。','喜欢逛书铺，也看人怎样议价。人在以为无关紧要时，话倒最真。','偶尔听人说书。只听故事，不一定非追问每一句来历。'],['话本里的人一眼便看透旁人，奴才倒想知道，他有没有看错过的那一回。','喜欢坐在茶馆听半晌闲话。真有要核的另记，不将每一句都算作消息。'],['有趣的几页留着了。今日若一同看，奴才保证，不在结尾处夹一份密报。','也想试试不替人圆话。您笑了便是笑了，不必再猜是赏谁的面子。']]}
}.items():
 for topic,stages in topics.items():
  for tier,texts in enumerate(stages): lines(npc,topic,tier,texts)

flirt={
'xu':[['陛下……言重了。臣尚有阁务，请容臣先回这一项。','臣不敢将陛下这句话，当成从前婚约仍在。','陛下若只是说笑，臣恐怕应不好。'],['这话再说下去，臣今日怕是不能好好回奏了。陛下也该有些分寸。','臣听见了。只是旧约已解，今日的话，须今日慢慢认。','您若回回这样看，臣总不能次次都当没看见。'],['臣有私心，但不会拿它作进退的条件。您要的首辅，臣仍会做好。','若是重新选一回，臣想与您并肩。不是交出印信，再等一道召幸的旨意。','旁人来见您，臣会在意。知道不该，也不等于便能全然不在意。']],
'jiang':[['陛下今日这句话，是试臣，还是另有所指？臣不敢替您定。','臣若顺着接了，陛下明日可别又说，是太傅教坏了规矩。','这话臣先记着。至于当作几分真，怕还得再看看。'],['臣原准备了好几句周全的话。如今看来，您大约一句也不想听。','陛下如今倒知道怎样叫臣接不上话了。这也在您的筹算里么？','不必拿这一句哄臣退荐单。私下的话，臣愿意另听。'],['臣并没有因此就忘了姜氏的事。可若说全不动摇，也是在欺君了。','原想将局势都算妥，偏没算到自己也有不愿退的一步。','您若是认真，便容臣也认真一回。只是这一次，臣不能再替您安排答案。']],
'xie':[['陛下这样看着，奴才连茶该往哪边放，都要多想一回。','奴才听见了。只是这句话，不敢替陛下传给旁人。','这份好听话，奴才可得收妥，免得转身便叫人讨了去。'],['许首辅若听见，怕又要将折子捏紧了。奴才？奴才自然高兴。','陛下若次次都这样问，奴才便不能只当是在逗一个当差的人。','没有旁人，您不必先找个由头。奴才就在这里。'],['奴才知道自己还有没交出的底牌。可今日这句喜欢，不想也藏在里面。','您身边谁想近一步，奴才都瞧得见。轮到自己，倒迟迟不敢把话说清。','这回不替谁添火了。奴才也有私心，想叫陛下先看这一回。']]}
tasks=[
dict(id='archive',title='核阅许案封卷',ap=1,days=2,source='刑部封卷与宫门收文簿',result='封卷结状的落款早于所据奏疏的签收，原案时序有冲突；可以申请重核，尚不能据此指认主使。'),
dict(id='witness',title='访寻当年移卷旧吏',ap=1,days=3,source='谢无咎的京中线人转述',result='线人称当年证词未当堂宣读便被收走。旧吏愿在另行保护后作证；目前仍是待核线索。'),
dict(id='ledger',title='对照姜叶旧荐授册',ap=1,days=2,source='吏部荐授原册',result='原案前后，姜叶门下均有人调入经手衙门。可证人事关联，不能将调任直接等同于构陷或谋逆。'),
dict(id='crosscheck',title='异源互核与证词复录',ap=1,days=2,source='宫门原簿、封卷原件与受保护证人的复录',requires=['archive','witness','ledger'],result='异源日期与复录证词互证：旧结状所列关键证词未经核对，许家原罪证不足。可以撤原结重审，幕后主使尚无足够独立证据。')]
data=dict(version='14.0',dynasty='大梁',era='景和',intro=intro,core=core,dialogue=dialogue,flirt=flirt,tasks=tasks)
write('daliang-canon-data',data)
world=read('world-data')
for id,c in core.items():
 world['core'][id].update(age=c['age'],gender='男',loyalty=c['loyalty'],specialty={'xu':'理政','jiang':'理政','xie':'察访'}[id],specialtyKey='admin')
 if id=='xie':world['core'][id]['faction']='内廷'
write('world-data',world)
cast=read('cast-data')
for p in cast['profiles']:
 if p['id'] not in core: continue
 id=p['id'];c=core[id];p.update(name=c['name'],habit=c['daily'],inner=c['want'],daily=c['daily'],bio=c['public'],background=c['public'],specialty={'xu':'理政','jiang':'理政','xie':'察访'}[id],specialtyKey='admin')
 if id=='xie':p.update(clan='来处未明',parents=[],grandparent=None)
for n in cast['familyNodes']:
 if n['id']=='g-xu':n.update(name='许阁老',alive=False,role='三朝阁臣 · 九公主恩师 · 旧案身故')
cast['familyLinks']=[l for l in cast['familyLinks'] if not any(v in ('f-xie','m-xie','g-xie') for v in l.values() if isinstance(v,str))]
cast['familyNodes']=[n for n in cast['familyNodes'] if n['id'] not in ('f-xie','m-xie','g-xie')]
write('cast-data',cast)
story=read('story-data')
for id,c in core.items():
 old=story['core'][id];old.update({k:c[k] for k in ('public','scar','truth','originReply','want','daily','item','evidence')})
 old['origin']={'xu':'fallen','jiang':'gentry','xie':'fallen'}[id]
 old['choices']=[['test','将这件事另据原件核实',c['evidence']],['listen','只听他把话说完','臣记下了。今日说过的话，不拿来混作政务上的交换。' if id!='xie' else '奴才记下了。您肯听，便不必每一句都先找个差事作由头。']]
 old['follow']=[['继续听他说',c['scar']],['先不追问','今日便先说到这里。']]
write('story-data',story)
ruin=read('ruined-realm-data');ruin['intro']='\n\n'.join(intro)
for id,c in core.items():
 if id in ruin['core']:ruin['core'][id].update(loyalty=c['loyalty'],ambition=c['ambition'],influence=c['influence'],stance=c['want'])
for t in ruin['routes']:
 if t['id']=='inventory':t.update(actor='jiang',reply='“原册可以交，点交的人也须各有签认。”姜禹瀛答得温和，“臣不拦陛下核库，也请陛下别将旧经手一笔抹去。”')
 if t['id']=='collect':t.update(actor='ye',reply='“只催已核的欠解，不碰灾户。”叶承钧将路线列清，“臣替陛下催，也请另派人对到账的数。”')
write('ruined-realm-data',ruin)
front=read('frontcourt-data')
def clean(x):
 if isinstance(x,str):return x.replace('姜太傅','姜禹瀛').replace('老臣','臣')
 if isinstance(x,list):return [clean(v) for v in x]
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 return x
if 'jiang' in front['bespokeAdvice']:front['bespokeAdvice']['jiang']=clean(front['bespokeAdvice']['jiang'])
front['bespokeAdvice']['jiang']={
'flood':'灾册须核，沿河旧员也不宜一纸尽撤。臣会列经手名册，陛下另派人验账；能办事的留下，有据的过错另问。',
'famine':'先续口粮，再定种贷。地方有望之户可作保，作保便须具名，不宜让他们只出一张荐书，往后却仍说与自己无涉。',
'transport':'若涉及姜氏门下，臣准其回避本案。只是请按具体经手查，不要用一份未核的告状，替换整条转运人事。',
'border':'援饷须办，领援之将却要另议。诸镇兵权不宜归于一门，姜叶所荐也都须列实绩，不能只凭拥立之功。',
'examleak':'涉者可先回避，榜册仍须一份份核。姜氏荐出的人也在其中，臣不求免查，也不许只因门生二字便先定罪。',
'trade':'可准小额试易，礼部与户部分别验物议价。叶氏熟悉商路，倒也不必将签核一并交去；懂行与独掌，是两回事。',
'deficit':'世家能垫的钱，不等于陛下能拨的国库。若先收叶氏垫付，借据与荐举便要分开，不宜将银债又还成人事。',
'epidemic':'调医与核册分办。地方旧任熟悉户籍，可留其协助，却须另有人验回单；救急不必等，人事也不能借救急尽归一处。'}
write('frontcourt-data',front)
game=(P/'demo-game.js').read_text(encoding='utf-8')
for id,c in core.items():
 pattern=r" \{id:'"+id+r"',[^\n]+"
 line=" {id:"+json.dumps(id)+",name:"+json.dumps(c['name'],ensure_ascii=False)+",age:"+str(c['age'])+",role:"+json.dumps(c['role'],ensure_ascii=False)+",type:"+json.dumps(c['type'],ensure_ascii=False)+",tone:'宫廷',color:"+json.dumps({'xu':'#758d81','jiang':'#6d7e95','xie':'#8b7686'}[id])+",initial:"+str({'xu':42,'jiang':22,'xie':48}[id])+",trust:"+str({'xu':64,'jiang':48,'xie':68}[id])+",romance:true,desc:"+json.dumps(c['desc'],ensure_ascii=False)+",open:'“陛下。”'},"
 game,n=re.subn(pattern,lambda _:line,game,count=1)
 # Idempotent after the first generation switched these fields to double quotes.
 if not n:game,n=re.subn(r' \{id:"'+id+r'",[^\n]+',lambda _:line,game,count=1)
 assert n==1,id
game=game.replace("openingScenario:'ruined-realm',", "openingScenario:'ruined-realm',canonScenario:'daliang-nine',") if "canonScenario:'daliang-nine'" not in game else game
(P/'demo-game.js').write_text(game,encoding='utf-8')
for name in ('demo-exploration.js','demo-frontcourt.js'):
 f=P/name;f.write_text(f.read_text(encoding='utf-8').replace('晟朝','大梁'),encoding='utf-8')
print(json.dumps({'core':list(core),'dialogue':len(dialogue),'tasks':len(tasks),'dynasty':'大梁'},ensure_ascii=False))
