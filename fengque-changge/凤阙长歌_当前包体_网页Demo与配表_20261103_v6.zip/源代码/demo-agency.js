'use strict';
// 活人感与自主意识层：最后加载，替换固定台词选择，并把 NPC 的日常行动变成可见事件。
const AGENCY_VOICES={
 '温柔体贴':{open:['我本想说无妨，见您这样问，倒不好再瞒。','您先坐稳些，我慢慢同您说。','这点小事原不值得惊动您，只是您既来了，我便想说一句。'],edge:['说到底，我也不是没有自己的心事。','您若只听好听的，我反倒不敢开口。','我愿意替您分忧，只盼您也记得问我一句。']},
 '清冷克制':{open:['我已经想过了，话可以直说。','事情不难，难的是有些话说出口便收不回来。','您既然亲自问，我便把能说的都说清。'],edge:['剩下的半句，我想等您先回答。','我不怕担责任，只是不愿替别人遮掩。','若要我点头，请把代价也一并告诉我。']},
 '明朗直率':{open:['我正要找您呢，您来得正好。','这事憋在心里怪难受的，既然见着您，我就直说。','您别只看我笑，我也有真正在意的事。'],edge:['我不喜欢猜，您有话就问。','好听的话我会高兴，难听的话也请当面说。','我可以让一步，但别让我一个人让。']},
 '骄矜自尊':{open:['您既来了，我便不装作不在意。','这句话若只是场面话，便不必说给我听。','我不缺一句赏赐，缺的是您认真看我一回。'],edge:['我可以体面地退开，却不会当作什么都没发生。','您要我的真心，便别只给我半截答案。','我有自己的分寸，也盼您别把它当成冷淡。']},
 '敏感多思':{open:['我在心里转了几遍，还是想亲口问您。','您若不嫌我多心，我想把这件事说明白。','我知道未必是那个意思，可我总要听您亲自说。'],edge:['我不是要您立刻答，只是不想再猜。','若是我想多了，您告诉我；若不是，也请别敷衍。','您说一句准话，我便能安心许多。']},
 '圆融世故':{open:['这话从谁口中传来的，我大概猜得到。','人人都有自己的难处，您想先听哪一层？','我可以替您留台阶，只是您得告诉我想走哪条路。'],edge:['我不替任何人作证，只把我看见的交给您。','话说满了容易伤人，留半寸也好回头。','您若真要我站队，便别只给我一句漂亮话。']},
 '严正守礼':{open:['臣先把规矩说在前头，再谈心意。','此事有章可循，若要破例，请陛下说明缘由。','您既问到臣，臣便不以好听话应付。'],edge:['该认的错臣认，没做过的事也不敢领。','情分可以商量，底线不能含糊。','请陛下把话说完，臣自会给出答复。']},
 '野心进取':{open:['您若肯把差事交给我，我便把结果交给您。','我不怕难，只怕被人用一句“以后再说”打发。','这件事我已经有了主意，只等您给我一个位置。'],edge:['我想要的从来不只是一句夸奖。','您若要我替您赢这一局，也该让我看见下一局。','我可以替您冲在前头，但不愿永远站在门外。']},
 '疏朗洒脱':{open:['我刚从外头回来，袖上还沾着风，您不嫌便听我说说。','宫墙里的人总爱把小事想得太重，先陪我笑一回？','我没有躲您，只是去看了看外面的天。'],edge:['若这条路走不通，换一条便是。','我愿意留下，是因为我自己想留下。','您若肯同行，我便把沿途最好的景色都指给您看。']},
 '务实重利':{open:['这件事先把利弊算清，再谈谁的面子。','我不怕吃亏，只怕吃了亏还不知道为何。','您若要我帮忙，请把能给我的退路说清。'],edge:['承诺要落在日子里，才算数。','您给我一句准话，我便能把账往下算。','情分我收着，账目也要明白。']},
 '寡言重诺':{open:['您问，我便说。只是说过的话，我会记很久。','事情我已经办了一半，剩下的等您一句。','我不善于哄人，您要听实话还是听安慰？'],edge:['答应过的事，我不会推给旁人。','没做过的，我不认；做错了，我会补。','您有空便来，没空也请让人说一声。']},
 '戒备善谋':{open:['门外有人么？没有便好，有些话不宜叫第三个人听见。','我先说我确定的，剩下的要等证据。','您肯亲自来，我愿意多交出一层。'],edge:['信任不是一句话，是一次次没有被利用。','我可以替您查，但不会把退路交出去。','若要我说真话，请先让我知道真话会落到谁手里。']}
};
const AGENCY_MOODS={
 '平静':['今日没有大事，正好把一件小事说完。','手头的事已收好，我还有一盏茶的工夫。'],
 '期待':['我原想着您或许会来，没想到真等到了。','这句话我已经在心里排了几遍。'],
 '热恋':['您一来，方才那些烦心事便都不算什么了。','我今日最盼的事已经到了。'],
 '吃醋':['我没想争，只是看见旁人有的，心里也会发酸。','您若问我是否在意，我不想再说没有。'],
 '失望':['我知道您忙，只是一次次改日，叫人不敢再等。','话我可以替您圆，心里的空处却圆不了。'],
 '委屈':['我不想闹，只想知道自己是不是又被放到最后。','这点委屈我能咽下，只是咽下以后还会记得。'],
 '安心':['您既然来了，便坐一会儿，今日不用急着走。','我知道您说到会来，就一定会来。'],
 '戒备':['这件事我还不能全说，您先听到这里。','我不是不信您，只是还没想好要把哪部分交出来。'],
 '恼怒':['我现在不想听漂亮话，先让我把事情说完。','您若要责我，至少把我做错的地方说清。'],
 '疏离':['公事我照办，旁的事改日再谈。','我没有生您的气，只是今日不想再猜。']
};
const AGENCY_TOPICS={
 chat:{recent:['今日衙门里争的是一笔旧账，人人都说自己只是在守规矩。','我路过东市，听见有人为一盏灯吵了半日，倒比朝堂上的话真。','这几日睡得不稳，醒来第一件事还是先看案头有没有新折子。'],home:['我家门前有一株老槐树，入秋时落叶很慢，像是舍不得人走。','家里人写信来问候，我回了许久，最后只写下“都好”两个字。','小时候我最怕雨天，如今在宫里听见雨声，反倒想起那条旧巷。'],interest:['我近来在学一件小事，做得不好，却不想让旁人代劳。','若给我半日闲，我想去看书、听曲，或只是沿着水边走走。','我喜欢的东西不贵，只是要有人肯认真听我讲完。']},
 care:{listen:['您不用急着替我想法子，听我把话说完就好。','这点疲惫我原能自己收着，您肯问，便值得说出来。','我不求您立刻替我做主，只想知道您没有略过我。'],comfort:['您陪我走一段，等风把这点闷意吹散，便好了。','不如把茶放凉些，我们都别急着回到那些折子里。','您若今日也累，便不必只照看我，我们一起歇一会儿。'],gift:['这东西您竟还记得，我当时只是随口提过。','礼物不在贵重，难得的是您把我说过的话放在心上。','我本想客气两句，拆开之后却舍不得再推回去。'],promise:['下月的日子若定下来，我便不会另作安排。','您若临时有事，提前告诉我，我不会叫人守着空门。','这一回我记下了，等您亲自来兑现。']},
 persuade:{support:['我可以替您担这一程，但请把最坏的结果也告诉我。','支持您不难，难的是让跟着我的人也愿意承担后果。','我会站在您这边，只是要知道您打算把谁留在身后。'],work:['这件事可以做，但要换个次序，先处理最容易失控的地方。','我愿意接下，只求您不要只看结果，也听我说说路上遇到的阻力。','若让我来办，我会把人情和账目分开，免得最后谁都说不清。'],reconcile:['我可以去找他谈，但不会假装从前的事没有发生。','和解不等于认输，至少要让他知道我为何不肯退。','我愿意给一步，剩下的一步要看他有没有诚意。']},
 probe:{opinion:['您问我怎么看自己？我只知道，我不愿做谁手里的棋子。','若说得直些，我希望您看见我的本事，也看见我的难处。','我还在等您用一件事证明，您问这句话不是随口。'],worry:['您问得突然。我有一件事放心不下，只是说出来便会牵连旁人。','我可以告诉您一半，另一半要等我确认您会如何处置。','心事并非没有，只是不能拿来换一句安慰。']},
 scold:{remind:['我听见了。若是我确实失了分寸，请您把缘由说清。','这句提醒我收下，但旁人的过错，别一并算到我头上。','您可以责我，只是请给我把话说完的机会。'],stern:['我认错，但不会替未做过的事低头。','您若要罚，我领；若要我改，也请说明要改成什么样。','这话很重，我会记着。等您肯听，我也要说说我的理由。'],public:['当众敲打，我自然会应下，只是从今以后，很多话我不会再在人前说。','今日体面给了朝堂，心里那一笔却要另记。','我不顶嘴，不等于我没有答案。']},
 activity:{chess:['这一局我不让您，输了也别拿身份压我。','棋子落下前我就想好了三步，您若看出来，算您赢。'],walk:['今日风不大，走慢些，别把这段路也走成了差事。','我有一件闲话想说，出了这道门便不算朝事。'],spar:['您站稳，我教您一招；学会之后别拿来对付我。','这一回我会收着力，您若真想赢，就别只看我的手。']},
 flirt:{compliment:['这句夸得太认真，我若当真，您可不能又说只是玩笑。','您若只对我说，我便愿意把它收好；若人人都有，我就不接了。'],miss:['您问我有没有想您？有，只是我不想把想念说成讨赏。','我当然想过您，只是想得多了，便会想知道您有没有想过我。'],confess:['这话若要说出口，便不能明日再拿玩笑收回。','我听见了。您若当真，我便也把自己的答案交给您。']},
 sleep:{ask:['今夜我愿意留下，但不想让一夜遮住白日里没说完的话。','我可以陪您守灯，只要您问的是我的心意，不是只问宫中的安排。','若您只是想找个人在身边，请先说实话，我才好回答。']}
};
const AGENCY_HOOKS={xu:'小时候那盏苦茶',jiang:'殿前那本旧策论',ye:'叶家账房里那只铁算盘',xie:'城外那间已经关门的书铺',song:'水榭里没有写完的半支曲子',lu:'京郊演武场那面旧靶旗'};
const AGENCY_GOALS={
 '温柔体贴':'照顾自己在意的人，也希望有人记得他的疲惫','清冷克制':'守住边界，把每件事做得无可指摘','明朗直率':'找一个能坦白说话、也愿意同行的人','骄矜自尊':'证明自己的价值，拒绝被当作可替代的赏赐','敏感多思':'确认承诺是否可靠，不再独自猜测','圆融世故':'维持各方体面，暗中换取真正的选择权','严正守礼':'守住规矩和底线，不让权势取代是非','野心进取':'获得能证明自己的差事与位置','疏朗洒脱':'保留自由，也把值得的人留在身边','务实重利':'把感情和日子都安排得有着落','寡言重诺':'用做成的事换取信任，不把话说空','戒备善谋':'搜集足够证据，在动心之前先保全自己'};
function agencyHash(s){if(typeof castHash==='function')return castHash(s);let n=2166136261;for(const c of String(s)){n^=c.charCodeAt(0);n=Math.imul(n,16777619);}return n>>>0;}
function agencyEnsure(){
 state.agency=Object.assign({version:1,days:{},moments:[],inbox:[],scenes:[],seq:0,currentTopic:null,currentRow:null},state.agency||{});
 state.agency.days=state.agency.days||{};state.agency.moments=state.agency.moments||[];state.agency.inbox=state.agency.inbox||[];state.agency.scenes=state.agency.scenes||[];
 for(const p of PEOPLE){const r=state.relations[p.id];r.agency=r.agency||{goal:AGENCY_GOALS[p.type]||'把自己的日子过好',plan:'',lastAction:'',used:[],trust:[],wounds:[],secrets:[],lastSeen:null};r.agency.used=r.agency.used||[];r.agency.wounds=r.agency.wounds||[];r.agency.secrets=r.agency.secrets||[];}
 return state.agency;
}
function agencyMood(p){
 const r=state.relations[p.id],m=r.mind||{},a=Number(m.anger||0),d=Number(m.disappointment||0),j=Number(m.jealousy||0),e=Number(m.expectation||0),s=Number(m.security||50);
 if(a>=55)return '恼怒';if(d>=48&&s<48)return '失望';if(j>=35&&r.rank)return '吃醋';if(d>=35)return '委屈';if(s<28)return '戒备';if(e>=34&&s>=55)return r.love>=25?'热恋':'期待';if(s>=72)return '安心';return typeof currentMind==='function'?currentMind(p):'平静';
}
function agencyTopic(id){
 const x=String(id||'visit');if(x.startsWith('relation:'))return 'opinion';if(x==='listen'||x==='comfort'||x==='gift'||x==='bag'||x==='promise')return x;if(x==='recent'||x==='home'||x==='interest')return x;if(x==='support'||x==='work'||x==='reconcile')return x;if(x==='opinion'||x==='worry')return x;if(x==='remind'||x==='stern'||x==='public')return x;if(x==='chess'||x==='walk'||x==='spar')return x;if(x==='compliment'||x==='miss'||x==='confess')return x;if(x==='ask'||x==='stay')return 'ask';return 'recent';
}
function agencyHook(p,topic){const r=state.relations[p.id],mem=r.mind?.memories?.slice().reverse().find(x=>x.text&&x.kind!=='自主日常');return AGENCY_HOOKS[p.id]||p.specialty||mem?.text?.split('。')[0]||p.desc||`${p.role||'自己的事'}`;}
function agencyPick(p,category,topic){
 agencyEnsure();const r=state.relations[p.id],a=r.agency,mood=agencyMood(p),voice=AGENCY_VOICES[p.type]||AGENCY_VOICES['温柔体贴'],pool=(AGENCY_TOPICS[category]?.[topic]||AGENCY_TOPICS[category]?.recent||AGENCY_TOPICS.chat.recent||[]);let key=`${p.id}|${category}|${topic}|${mood}|${state.elapsed}|${state.day}|${a.lastAction}|${a.used.length}`;if(state.agency.currentRow?.key===key)return state.agency.currentRow.row;let idx=agencyHash(key)%Math.max(1,pool.length),base='';for(let i=0;i<pool.length;i++){const cand=pool[(idx+i)%pool.length];if(!a.used.includes(cand)){base=cand;break;}}base=base||pool[idx%Math.max(1,pool.length)]||'我有话想同您说。';const moodPool=AGENCY_MOODS[mood]||AGENCY_MOODS['平静'],mline=moodPool[agencyHash(`${key}:mood`)%moodPool.length],opening=voice.open[agencyHash(`${key}:open`)%voice.open.length],edge=voice.edge[agencyHash(`${key}:edge`)%voice.edge.length],hook=agencyHook(p,topic);let reply=`${opening}“${base}”${mline}`;if(agencyHash(`${key}:hook`)%3===0)reply+=`我这几日还在记着${hook}。`;else reply+=`您若还想问，便问得具体些。`;
 a.used.push(base);a.used=a.used.slice(-30);const row={id:`A${agencyHash(key)}`,personality:p.type,mood,category,topic,stage:`${p.name}先看了看门外，才把声音放低。`,player:agencyPlayer(category,topic),reply,location:p.location||'quarters',key};state.agency.currentRow={key,row};return row;
}
function agencyPlayer(category,topic){const m={recent:'近来在忙什么？',home:'想同我说说你的故乡么？',interest:'若有半日闲，你最想做什么？',listen:'别急，我听你慢慢说。',comfort:'你看着有些累，先陪我坐一会儿。',gift:'这件东西我想着你，便留给你。',promise:'下月的日子，我们先约好。',support:'这件事，我想听你愿不愿意替我担一程。',work:'我有一桩差事，想先听听你的主意。',reconcile:'你与他之间的结，我想知道能不能松一松。',opinion:'你如何看待如今的自己？',worry:'若有一件事压在心里，你愿意告诉我么？',remind:'这件事我想提醒你一句。',stern:'今日这件事，你得给我一个说法。',public:'当着众人的面，我要把规矩说清。',chess:'陪我下一局，输赢都算作今日的闲话。',walk:'陪我走一段，不谈折子。',spar:'教我一招，别只说我学不会。',compliment:'我今日想认真夸你一句。',miss:'你有没有在某个时候想起过我？',confess:'有句话我不想再绕了。',ask:'今夜愿不愿意留下？'};return m[topic]||m[category]||'我想听你亲口说。';}
 // The earlier dialogue layers contain the authored scene, player prompt and
 // mood-specific reply. The old agency layer used to replace all of that with
 // “opening + quote + mood + hook”, which made every interaction sound assembled.
 // Keep agency for daily behaviour, but let the authored scene answer the player.
 const agencyRevisionBefore=revisionRow;
 const agencyReadBefore=readFiction;
 function agencyAuthoredRow(p,category,topic){
  const source=typeof revisionReadBefore==='function'?revisionReadBefore:agencyReadBefore;
  try{const row=source?source(p,category,topic):null;if(row&&row.scene){row.player=row.player||row.scene.player;row.location=row.location||row.scene.location;}return row;}catch(e){return null;}
 }
 revisionRow=function(p,category){
  const topic=agencyTopic(state.agency?.currentTopic||'recent');
  return agencyAuthoredRow(p,category,topic)||agencyRevisionBefore(p,category);
 };
 readFiction=function(p,category,topic){
  return agencyAuthoredRow(p,category,agencyTopic(topic||state.agency?.currentTopic||'recent'))||agencyReadBefore(p,category,topic);
 };
 const agencyInteractionBefore=interactionTopic;
 interactionTopic=function(id){agencyEnsure();state.agency.currentTopic=id;state.agency.currentRow=null;const out=agencyInteractionBefore(id);state.agency.currentTopic=null;state.agency.currentRow=null;return out;};
 actions.interactionTopic=interactionTopic;
 const agencyVisitBefore=visit;
 visit=function(id){agencyEnsure();state.agency.currentTopic='recent';state.agency.currentRow=null;agencyVisitBefore(id);state.agency.currentTopic=null;state.agency.currentRow=null;};
 actions.visit=visit;
 const AGENCY_DAILY={
  '温柔体贴':['把手边的茶换成温的，又替熟人回了一封家信。','在花房里照看新芽，听见宫门响了两回，仍没有催人来。'],
  '清冷克制':['把三份折子按轻重重新排过，最后一笔亲自落款。','在藏书阁查了半日旧档，连午膳也只叫人送到门口。'],
  '明朗直率':['从演武场回来，顺手给同伴带了两串热栗子。','把一桩小争执说开了，临走还笑着叫人下回当面来问。'],
  '骄矜自尊':['把新做的文章压在案下，等一个真正懂得看的人。','听见旁人议论自己，只淡淡一笑，转身把该做的事做完。'],
  '敏感多思':['写了又撕一张信，最后只留下“近日可好”四字。','在廊下站了许久，听见脚步声靠近，又先一步退回灯影里。'],
  '圆融世故':['替两边各留了半步台阶，自己却把最难的那句收在心里。','从东市带回一桩新消息，先问清谁愿意听，再慢慢开口。'],
  '严正守礼':['按时点完名册，连一处错字也不肯留到明日。','有人求情，他只回了一句“把章程拿来”，便不再多说。'],
  '野心进取':['把一份请命折改了三遍，直到每个数字都能落到实处。','在演武场多留了一刻，像是要让所有旁观的人记住这一箭。'],
  '疏朗洒脱':['绕去西市买了新伞，回来时鞋上沾泥，也不许人替他擦。','在水榭坐到日影偏西，忽然起身去找一个许久未见的旧友。'],
  '务实重利':['把本月用度重新算过，省下的钱另立一笔以备急用。','亲自去看了库房，回来只说“账对得上，心才安”。'],
  '寡言重诺':['把答应别人的事一件件做完，晚膳时才想起自己还没吃东西。','修好一方旧砚，放回原处，没有特意告诉任何人。'],
  '戒备善谋':['把来往名册收进暗格，明面上只留一张无关紧要的抄本。','听完旁人的话没有立刻表态，回房后才把疑点逐条记下。']
 };
 function agencyActionFor(p,key){const r=state.relations[p.id],m=r.mind||{},mood=agencyMood(p),h=agencyHash(`${key}:${p.id}:${r.agency.lastAction}`),edges=socialEdgesOf(p.id).filter(e=>{const id=e.a===p.id?e.b:e.a;return PEOPLE.some(q=>q.id===id);});const target=edges.length?PEOPLE.find(q=>q.id===(edges[h%edges.length].a===p.id?edges[h%edges.length].b:edges[h%edges.length].a)):null;
  if(['恼怒','疏离'].includes(mood))return {kind:'withdraw',target,text:`${p.name}照常做完该做的事，之后把门掩上，暂不接待访客。`};
  if(mood==='吃醋'&&r.rank)return {kind:'jealous',target,text:`${p.name}听见女帝今日召见${target?.name||'旁人'}，把原想递上的话收回袖中，改托人送来一盏冷茶。`};
  if(mood==='失望'||mood==='委屈')return {kind:'letter',target,text:`${p.name}写了一封信，写到“改日”二字时停了很久，最后只留下：“若您得空，请给我一个准信。”`};
  if(state.strife?.threat>=55&&((p.skills?.military||0)>55||p.id==='lu'))return {kind:'petition',target,text:`${p.name}主动整理边报，准备请命去看${state.strife.threat>70?'北境关口':'边营粮道'}。`};
  if(p.official&&((p.skills?.admin||0)>55||p.id==='xu'))return {kind:'work',target,text:`${p.name}把手头的折子重新分了三摞，先处理最容易牵动民心的一件。`};
  if(target&&h%3===0)return {kind:'social',target,text:`${p.name}在${p.location?'旧日常去的地方':'廊下'}遇见${target.name}，两人先谈公事，后来声音渐低，旁人听不见了。`};
  if(p.romance&&r.aff>=35&&h%4===0)return {kind:'invite',target,text:`${p.name}让宫人递话，说想请女帝得空时来坐坐；末尾又添了一句：“若忙，回我一字也好。”`};
  const daily=(AGENCY_DAILY[p.type]||AGENCY_DAILY['温柔体贴'])[h%2];return {kind:'goal',target,text:`${p.name}${daily}`};
 }
 function agencyCreateScene(p,action,key){const t=action.target;if(!t||!state.relations[t.id])return;const pm=state.relations[p.id].mind||{},tm=state.relations[t.id].mind||{};if(!(action.kind==='jealous'||action.kind==='social'||pm.jealousy>=28||tm.jealousy>=28))return;const a=state.agency;if(a.scenes.some(x=>!x.done&&x.dayKey===key))return;const id=`scene-${++a.seq}`;a.scenes.push({id,dayKey:key,source:p.id,target:t.id,title:`${p.name}与${t.name}的廊下话`,text:`宫人说，${p.name}与${t.name}在廊下相遇。一个说“只是路过”，一个却把手里的请帖攥得发皱。您若现在过去，还来得及听见原话。`,done:false});}
 function agencyTickDay(key){agencyEnsure();if(state.agency.days[key])return;state.agency.days[key]=true;let sceneMade=false;for(const p of PEOPLE){const r=state.relations[p.id];const action=agencyActionFor(p,key),m=r.mind||{};r.agency.lastAction=action.kind;r.agency.lastSeen=key;r.agency.plan=action.text;const moment={id:`moment-${++state.agency.seq}`,key,npc:p.id,name:p.name,kind:action.kind,target:action.target?.id||null,text:action.text,month:state.elapsed,day:state.day||1};state.agency.moments.push(moment);if(state.agency.moments.length>220)state.agency.moments.shift();if(['jealous','letter','petition','invite','social'].includes(action.kind)){r.notes.push({month:state.elapsed,text:`${state.day||1}日 · ${action.text}`});if(typeof rememberMind==='function')rememberMind(p.id,action.text,'自主行动',true);}if(action.kind==='social'&&action.target){const e=socialEdgesOf(p.id).find(x=>x.a===action.target.id||x.b===action.target.id);if(e){const own=e.a===p.id?'affAB':'affBA';e[own]=clamp((e[own]||40)+(agencyHash(`${key}:${p.id}:edge`)%3)-1);e.recent=action.text;}}if(!sceneMade&&action.target&&(action.kind==='jealous'||action.kind==='social')){agencyCreateScene(p,action,key);sceneMade=true;}if(['letter','petition','invite'].includes(action.kind)&&state.agency.inbox.filter(x=>!x.done).length<8){state.agency.inbox.push({id:`mail-${++state.agency.seq}`,source:p.id,target:action.target?.id||null,kind:action.kind,title:action.kind==='petition'?'一封请命折':action.kind==='invite'?'有人递话':'写到一半的信',text:action.text,dayKey:key,done:false});}}
  const old=Object.keys(state.agency.days);for(const k of old.slice(0,-90))delete state.agency.days[k];save();}
 const agencyBuildBefore=buildDay;buildDay=function(){const key=agencyBuildBefore();agencyTickDay(key);return key;};
 function agencyPanel(){agencyEnsure();const key=todayKey(),mom=state.agency.moments.filter(x=>x.key===key).slice(-12).reverse(),mail=state.agency.inbox.filter(x=>!x.done).slice(-8).reverse(),scenes=state.agency.scenes.filter(x=>!x.done).slice(-4);openModal('今日人物动向','他们不在等您点击，也在过自己的日子。',`${mail.length?`<h3>有人递来的话</h3>${mail.map(x=>`<div class="record"><span class="tag">${strifeName(x.source)}</span><p>${x.text}</p><button class="btn ghost" data-action="agencyOpen" data-id="${x.id}">拆开看看</button></div>`).join('')}`:''}${scenes.length?`<h3 class="section-space">宫中正在发生</h3>${scenes.map(x=>`<div class="record"><b>${x.title}</b><p>${x.text}</p><button class="btn primary" data-action="agencyOpen" data-id="${x.id}">现在过去</button></div>`).join('')}`:''}<h3 class="section-space">今日公开行迹</h3>${mom.map(x=>`<div class="record"><span class="mini">${x.name} · ${x.kind}</span><p>${x.text}</p></div>`).join('')||'<p class="mini">今日的记录还未展开。去地图或人物页看一眼，会留下新的行迹。</p>'}`,'人物自主意识');}
 function agencyOpen(id){agencyEnsure();const mail=state.agency.inbox.find(x=>x.id===id&&!x.done),scene=state.agency.scenes.find(x=>x.id===id&&!x.done);if(mail){const p=PEOPLE.find(x=>x.id===mail.source);openModal(mail.title,`${p?.name||'有人'} · ${agencyMood(p||PEOPLE[0])}`,`<div class="scene-text">${mail.text}<br><br>字迹停在最后一句，像是等您先回话。</div><div class="opts"><button class="opt" data-action="agencyChoose" data-id="${id}|answer"><b>回信，叫他把话说完</b><small>安心上升；这件事会继续发展。</small></button><button class="opt" data-action="agencyChoose" data-id="${id}|delay"><b>先收下，等忙完再说</b><small>不耗行动；对方会记住这次等待。</small></button><button class="opt" data-action="agencyChoose" data-id="${id}|visit"><b>现在亲自去见</b><small>消耗1行动；当面听他把话说完。</small></button></div>`,'人物来信');return;}if(scene){openModal(scene.title,'谢无咎：“两个人的话都只说了一半。”',`<div class="scene-text">${scene.text}</div><div class="opts"><button class="opt" data-action="agencyChoose" data-id="${id}|listen"><b>站在廊下，先听原话</b><small>不急着判谁对谁错。</small></button><button class="opt" data-action="agencyChoose" data-id="${id}|call"><b>把两人都叫来问</b><small>当面说清，可能有人记恨。</small></button><button class="opt" data-action="agencyChoose" data-id="${id}|leave"><b>暂不插手</b><small>让关系自行发展。</small></button></div>`,'人物往来');}}
 function agencyChoose(raw){const [id,choice]=String(raw).split('|'),a=state.agency,mail=a.inbox.find(x=>x.id===id),scene=a.scenes.find(x=>x.id===id);if(mail){const p=PEOPLE.find(x=>x.id===mail.source),r=state.relations[mail.source];if(choice==='visit'){if(!pay(1))return;mail.done=true;shiftMind(mail.source,{security:6,expectation:4,disappointment:-4});rememberMind(mail.source,'女帝没有让递来的话停在半路，亲自来听我说。','回应',true);closeModal();render();result('当面听他说完',`${p.name}把信收回袖中，先问：“您今日肯来，是因为看见了这封信，还是因为本来就想来？”`,'行动−1；这段话会继续留在他的记事里。');return;}mail.done=true;if(choice==='answer'){shiftMind(mail.source,{security:4,expectation:3,disappointment:-2});rememberMind(mail.source,'女帝回了信，至少没有让一句话落空。','回信',true);log(`你回了${p.name}递来的话，请他把未完的事继续说。`,'人物来信',mail.source);}else{shiftMind(mail.source,{expectation:-4,disappointment:3});rememberMind(mail.source,'递去的话暂时没有等到回音。','等待',true);log(`${p.name}递来的话暂缓回应。`,'人物来信',mail.source);}closeModal();render();result('回音已留下',choice==='answer'?`${p.name}看见回信后，把原本揉皱的纸重新铺平。`:`这封信先收进匣中。${p.name}没有催，却把今日的等待记下了。`,'人物关系会在后续日子里变化。');return;}if(scene){scene.done=true;const p=PEOPLE.find(x=>x.id===scene.source),t=PEOPLE.find(x=>x.id===scene.target);if(choice==='listen'){state.relations[scene.source].mind&&shiftMind(scene.source,{security:2,anger:-2});log(`你在廊下听见${p.name}与${t.name}的原话，没有急着偏袒任何一方。`,'人物往来',scene.source);}else if(choice==='call'){state.relations[scene.source].mind&&shiftMind(scene.source,{anger:4,disappointment:2});state.relations[scene.target].mind&&shiftMind(scene.target,{anger:4,disappointment:2});log(`你将${p.name}与${t.name}都叫来问话，关系暂时止住，心里却各自留下了账。`,'人物往来',scene.source);}else{state.relations[scene.source].mind&&shiftMind(scene.source,{expectation:2});log(`你没有插手${p.name}与${t.name}的争执，宫里暂记为未决。`,'人物往来',scene.source);}closeModal();render();result('这一段往来有了回声',`${p.name}与${t.name}各自回到原处，谁也没有把最后一句说出口。`,'关系没有归零，往后的选择仍会改变它。');}}
 actions.agencyPanel=agencyPanel;actions.agencyOpen=agencyOpen;actions.agencyChoose=agencyChoose;
 const agencyAuditionBefore=auditionInterview;
 function agencyAuditionLine(p,i){const mood=agencyMood(p),type=p.type||'温柔体贴',special=p.specialty||(p.skills?.literature>60?'读书与写字':p.skills?.military>60?'骑射与军略':'琴棋与家学');const lead={温柔体贴:['家里有人照应，我是自己想来的，想看看宫里的日子。','我会照料花木，也会做几样家常菜，闲时不怕没有事做。','我知道宫里不是只讲情分。若陛下留我，我愿意把日子过好；若不留，也请让我体面回家。'],清冷克制:['这是我自己选的路，家中并未替我应下。','我习的是'+special+'，不算惊世骇俗，却足够让我独自立身。','我愿意留下，但有些界限要先说清，彼此都不为难。'],明朗直率:['我自己要来的，家里劝过，我没听。','我会'+special+'，也会骑马走远路，您若闷了可以叫我。','我愿意，只是陛下忙也要留句话，别叫我一个人猜。'],骄矜自尊:['我想见陛下，也想让自己的本事有个去处。','我不靠一声赏便留下。琴棋书画我都学过，最拿手的是'+special+'。','我可以入宫，但请不要把我当成席间一件摆设。'],敏感多思:['家里说这是好机会，我也想知道自己到底愿不愿意。','我会'+special+'，只是人多时容易紧张，若出了错请别立刻定我。','我愿意留下，但希望陛下有事直说，不要叫我在沉默里猜。'],圆融世故:['家里让我来，我也想替自己看看路。','我会'+special+'，若陛下愿意听，我还能说说家中与京城的人情。','我可以留下，不过宫里的规矩和各人的脾气，最好先说清。'],严正守礼:['奉召而来，家中已知晓。','臣所长是'+special+'，不敢夸口，只愿当面试过。','若陛下允准，臣愿守宫规；若不允，也请依礼送我出宫。'],野心进取:['我来应选，是想把本事用到更大的地方。','我最擅长'+special+'，若只叫我候在宫里，未免浪费。','我愿意留下，但希望陛下给我一件能亲手做成的事。'],疏朗洒脱:['我自己来的，家里只说别在宫里闯祸，我答应得不算认真。','我会'+special+'，也喜欢出门看山水，整日困在一处会闷。','我愿意，只要宫里容我保留一点自己的日子。'],务实重利:['家中希望我寻个安稳去处，我也想替家里省一层忧。','我会'+special+'，若将来能管些实际事务，便更好。','我愿意留下，但家中有事时，请准我寄信，不要只说以后再议。'],寡言重诺:['家里知情。我想来，便来了。','我会'+special+'，不必先夸，试过便知道。','我愿意。答应的事，我会记着，也希望陛下如此。'],戒备善谋:['家中递了荐书，我自己也想看看宫门里究竟是什么样。','我会'+special+'，旁的本事也学过一些，只是不急着全说。','我可以留下，但愿意与否要由我自己决定，不能由家书代答。']};let arr=lead[type]||lead['温柔体贴'];let line=arr[i]||arr[0];const moodLine=(AGENCY_MOODS[mood]||AGENCY_MOODS['平静'])[agencyHash(`${p.id}:aud:${i}:${state.elapsed}`)%2];return `${line}${mood==='戒备'||mood==='失望'?' '+moodLine:''}`;}
 function agencyAuditionAsk(raw){const[id,idx]=String(raw).split('|'),i=Number(idx),au=state.audition,p=PEOPLE.find(x=>x.id===id);if(au.status!=='offered'||!au.pool.includes(id)||![0,1,2].includes(i))return;au.interviews[id]=au.interviews[id]||[];if(!au.interviews[id].includes(i))au.interviews[id].push(i);auditionInterview(id,agencyAuditionLine(p,i));}
 auditionInterview=function(id,answer=''){const p=PEOPLE.find(x=>x.id===id);agencyAuditionBefore(id,answer||`${p?.name||'他'}行礼后没有急着低头：“陛下想先问家世，还是先看我所习的本事？”`);};actions.auditionAsk=agencyAuditionAsk;actions.auditionInterview=id=>auditionInterview(id);
 const agencyRenderBefore=render;render=function(){agencyEnsure();agencyRenderBefore();if(state.tab==='home'&&!document.querySelector('.agency-home')){const anchor=document.querySelector('.strife-home')||document.querySelector('.stats')||document.querySelector('#screen .court-entry');if(anchor)anchor.insertAdjacentHTML('afterend',`<div class="agency-home"><div class="card"><div class="section-heading"><h3>今日人物动向</h3><span class="tag">${state.agency.inbox.filter(x=>!x.done).length}封新话</span></div><p>${state.agency.moments.filter(x=>x.key===todayKey()).slice(-3).map(x=>x.text).join(' ')||'大家正各自忙着。去人物页看看，今日的行迹会慢慢显出来。'}</p><button class="btn ghost wide" data-action="agencyPanel">查看今日动向与来信</button></div></div>`);}};save();
 const agencyStyle=document.createElement('style');agencyStyle.textContent=`.agency-home{margin-top:15px}.agency-home .card{background:#fffaf2;border-color:#decfc0}.agency-home p{font-size:13px;line-height:1.9;color:#806d73}.agency-home .tag{font-size:10px}.agency-home+.card{margin-top:15px}`;document.head.appendChild(agencyStyle);
 agencyEnsure();buildDay();



